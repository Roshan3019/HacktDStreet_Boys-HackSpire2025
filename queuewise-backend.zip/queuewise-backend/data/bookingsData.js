module.exports = [
  {
    id: "b1",
    centerName: "City Hospital",
    date: "2025-04-28",
    timeSlot: "10:00 AM - 10:30 AM",
    status: "upcoming"
  }
];
