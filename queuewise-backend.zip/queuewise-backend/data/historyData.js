module.exports = [
  {
    id: "h1",
    centerName: "Downtown Service Center",
    date: "2025-04-20",
    waitTime: "25 mins",
    status: "completed"
  }
];
