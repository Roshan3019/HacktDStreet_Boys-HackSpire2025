module.exports = {
  totalCenters: 5,
  activeQueues: 3,
  avgWaitTime: "20 mins",
  peakHour: "11:00 AM"
};
