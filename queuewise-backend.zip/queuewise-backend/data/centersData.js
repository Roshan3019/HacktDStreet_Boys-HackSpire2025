module.exports = [
  {
    id: "1",
    centerName: "City Hospital",
    currentQueueLength: 12,
    averageWaitTime: "15 mins",
    anomalyDetected: false,
  },
  {
    id: "2",
    centerName: "Downtown Service Center",
    currentQueueLength: 30,
    averageWaitTime: "45 mins",
    anomalyDetected: true,
  }
];
