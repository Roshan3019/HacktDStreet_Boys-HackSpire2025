module.exports = [
  {
    id: "r1",
    recommendedCenter: "City Hospital",
    recommendedTime: "2:00 PM - 3:00 PM"
  }
];
