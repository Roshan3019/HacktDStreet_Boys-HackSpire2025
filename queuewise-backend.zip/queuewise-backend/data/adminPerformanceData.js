module.exports = {
  accuracy: "92%",
  satisfactionRate: "87%",
  systemHealth: "Good"
};
